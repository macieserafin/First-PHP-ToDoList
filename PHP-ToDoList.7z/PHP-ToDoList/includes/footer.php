<footer>
    <p>© <?= date('Y'); ?> Maciej Serafin. Wszystkie prawa zastrzeżone.</p>
</footer>
</body>
</html>
