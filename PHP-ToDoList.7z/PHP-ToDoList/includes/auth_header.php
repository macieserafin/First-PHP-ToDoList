<header class="custom-header">
    <div class="custom-logo">
        <a href="home.php" class="custom-logo-link">ToDoMaster</a>
    </div>
    <div class="custom-auth">
        <a href="login.php" class="custom-login">Zaloguj się</a>
        <a href="register.php" class="custom-register">Zacznij teraz</a>
    </div>
</header>
